WEBSITE PEMERINTAH NEGERI ADMINISTRATIF PULAU AY — V2
Periode arsip: 2026–2033.

CARA MENJALANKAN:
- Ekstrak ZIP.
- Buka index.html di browser untuk melihat demo.
- Untuk GitHub: unggah seluruh isi folder ini ke root repository (jangan hanya index.html).
- Untuk Cloudflare Pages: hubungkan repository GitHub, framework preset None, build command kosong, output directory / (root).

PENTING:
- Logo dan foto di folder assets adalah placeholder. Ganti dengan logo resmi dan foto yang benar.
- Modul arsip pada versi statis ini menampilkan struktur tahun/kategori dan tautan dokumen contoh. Penyimpanan unggahan publik membutuhkan backend/storage dan login admin.
- Generator surat membuat pratinjau yang dapat dicetak dari browser. Belum menghasilkan DOCX/PDF resmi otomatis, belum memberi nomor surat otomatis dari register resmi, dan belum menyimpan data.
- Jangan unggah NIK, KK, data ahli waris, atau dokumen berisi data pribadi ke repository publik.
- Bagan kelembagaan perlu disesuaikan dengan peraturan/nomenklatur resmi Negeri Administratif Pulau Ay dan Kabupaten Maluku Tengah.
